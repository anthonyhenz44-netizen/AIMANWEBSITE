
import React, { useState } from 'react';
import { 
  ArrowLeft, 
  Clock, 
  MapPin, 
  CheckCircle2, 
  ShieldCheck, 
  Zap,
  Plus,
  Minus,
  HelpCircle
} from 'lucide-react';

interface WhyAIPageProps {
  onBack: () => void;
  onGetDemo?: () => void;
}

const FAQItem = ({ question, answer }: { question: string, answer: string }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="border-b border-slate-200 py-6 transition-all">
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex justify-between items-center text-left gap-4 group"
      >
        <h3 className={`text-xl font-bold transition-colors ${isOpen ? 'text-blue-600' : 'text-slate-900 group-hover:text-blue-600'}`}>
          {question}
        </h3>
        <div className={`shrink-0 w-8 h-8 rounded-full flex items-center justify-center transition-all ${isOpen ? 'bg-blue-600 text-white rotate-0' : 'bg-slate-100 text-slate-400 rotate-90'}`}>
          {isOpen ? <Minus size={18} /> : <Plus size={18} />}
        </div>
      </button>
      <div className={`overflow-hidden transition-all duration-300 ${isOpen ? 'max-h-96 mt-4 opacity-100' : 'max-h-0 opacity-0'}`}>
        <p className="text-slate-600 leading-relaxed text-lg">
          {answer}
        </p>
      </div>
    </div>
  );
};

const WhyAIPage: React.FC<WhyAIPageProps> = ({ onBack, onGetDemo }) => {
  const faqs = [
    {
      question: "Does this replace my office phone number?",
      answer: "Not at all. Think of the AI Agent as your digital receptionist. It handles the 'low-level' traffic—people looking for pricing, checking your service area, or asking for quotes at 11 PM. Your phone is still for those deep, high-value conversations you need to have with your customers."
    },
    {
      question: "How does the AI know my specific pricing and services?",
      answer: "During our setup process, we 'train' your specific AI Agent using your service list, pricing guides, and business rules. It only says what you want it to say. If it doesn't know an answer, it gracefully collects the lead's info and tells them you'll get back to them personally."
    },
    {
      question: "What happens if the AI says something wrong?",
      answer: "Our 'Guardrail Technology' ensures the AI stays within the bounds of your business. We test every agent rigorously against your specific trade requirements. Plus, you get a full transcript of every conversation sent to your email or via SMS immediately."
    },
    {
      question: "Can you install this on my current website?",
      answer: "To guarantee the 'boots-on-the-ground' reliability and lightning-fast speed we are known for, we build all our AI-powered solutions on a fresh, modern foundation. We do not incorporate our technology into existing or older websites. Our clients get a complete, high-performance digital employee built from the ground up to ensure peak performance and 24/7 reliability."
    },
    {
      question: "How much time does this actually save me?",
      answer: "Our typical Rockland trade clients save 10-15 hours per week on 'admin' tasks. That's time you currently spend answering the same 5 questions on the phone or chasing down basic details from email leads. The AI delivers pre-qualified jobs directly to your pocket."
    }
  ];

  return (
    <div className="bg-white min-h-screen animate-in fade-in duration-500">
      {/* Header */}
      <div className="bg-slate-50 border-b border-slate-200 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <button 
            onClick={onBack}
            className="flex items-center gap-2 text-blue-600 font-bold text-sm uppercase tracking-widest mb-8 hover:gap-3 transition-all"
          >
            <ArrowLeft size={18} /> Back to Home
          </button>
          <h1 className="text-4xl md:text-6xl font-bold text-slate-900 leading-tight">
            Why Rockland Trades Are <span className="text-blue-600 underline decoration-blue-200 underline-offset-8">Ditching Forms</span> For AI
          </h1>
          <p className="mt-6 text-xl text-slate-600 max-w-3xl leading-relaxed">
            In Rockland County, the trades are competitive. If you don't answer the phone, the next guy in New City or Nanuet will. Here is why AI is the unfair advantage your business needs.
          </p>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="grid lg:grid-cols-2 gap-20 items-start">
          
          {/* Reason 1: The 5-Minute Rule */}
          <div className="space-y-6">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-600 text-white rounded-2xl shadow-xl">
              <Clock size={32} />
            </div>
            <h2 className="text-3xl font-bold text-slate-900">1. The "5-Minute Window"</h2>
            <p className="text-lg text-slate-600 leading-relaxed">
              Statistics show that you have less than 5 minutes to respond to a lead before they call a competitor. In the time it takes you to finish a job in Nyack and check your email, that customer has already booked with someone else.
            </p>
            <div className="bg-slate-50 p-6 rounded-xl border-l-4 border-blue-600">
              <p className="text-sm font-bold text-slate-900 mb-2">THE AI ADVANTAGE:</p>
              <p className="text-slate-600">Our AI Agents respond in 1.5 seconds. They catch the lead while the customer is still on your website, not after they've moved on to Google search again.</p>
            </div>
          </div>

          {/* Reason 2: Geographic Intelligence */}
          <div className="space-y-6">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-purple-600 text-white rounded-2xl shadow-xl">
              <MapPin size={32} />
            </div>
            <h2 className="text-3xl font-bold text-slate-900">2. Local Service Area Intelligence</h2>
            <p className="text-lg text-slate-600 leading-relaxed">
              Standard chatbots don't know the difference between Pearl River and Stony Point. Our AI is trained on Rockland County geography. 
            </p>
            <ul className="space-y-3">
              <li className="flex items-center gap-3 text-slate-700 font-semibold">
                <CheckCircle2 size={18} className="text-green-500" /> It knows where you do (and don't) work.
              </li>
              <li className="flex items-center gap-3 text-slate-700 font-semibold">
                <CheckCircle2 size={18} className="text-green-500" /> It can calculate rough travel times for estimates.
              </li>
              <li className="flex items-center gap-3 text-slate-700 font-semibold">
                <CheckCircle2 size={18} className="text-green-500" /> It builds trust by mentioning local landmarks or towns.
              </li>
            </ul>
          </div>

          {/* Reason 3: Pre-Qualification */}
          <div className="space-y-6">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-orange-600 text-white rounded-2xl shadow-xl">
              <ShieldCheck size={32} />
            </div>
            <h2 className="text-3xl font-bold text-slate-900">3. Eliminating "Tire Kickers"</h2>
            <p className="text-lg text-slate-600 leading-relaxed">
              Not every lead is a good lead. You shouldn't be driving across the county for a job that doesn't fit your business.
            </p>
            <p className="text-slate-600">
              The AI Agent asks the critical questions first:
              <span className="block mt-4 italic text-slate-900 font-medium">"What is the specific issue? Is this an emergency? Do you own the property? Are you looking for service today or an estimate?"</span>
            </p>
            <div className="flex items-center gap-2 text-orange-600 font-bold">
              <Zap size={20} /> You only talk to the people ready to pay.
            </div>
          </div>

          {/* Reason 4: Reducing Owner Burnout */}
          <div className="space-y-6">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-green-600 text-white rounded-2xl shadow-xl">
              <Zap size={32} />
            </div>
            <h2 className="text-3xl font-bold text-slate-900">4. Reclaim Your Sunday Night</h2>
            <p className="text-lg text-slate-600 leading-relaxed">
              Most trade owners spend 10-15 hours a week just answering basic questions or returning voicemails. 
            </p>
            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 bg-slate-50 rounded-lg">
                <p className="text-2xl font-bold text-blue-600">24/7</p>
                <p className="text-xs text-slate-500 font-bold uppercase tracking-widest">Availability</p>
              </div>
              <div className="p-4 bg-slate-50 rounded-lg">
                <p className="text-2xl font-bold text-blue-600">0%</p>
                <p className="text-xs text-slate-500 font-bold uppercase tracking-widest">Wait Time</p>
              </div>
            </div>
            <p className="text-slate-600">
              Imagine waking up on a Monday morning with 3 pre-qualified jobs already in your text messages, instead of a list of people you have to call back.
            </p>
          </div>
        </div>

        {/* FAQ Section */}
        <div className="mt-32">
          <div className="flex items-center gap-3 mb-10">
            <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-xl flex items-center justify-center">
              <HelpCircle size={24} />
            </div>
            <h2 className="text-3xl font-bold text-slate-900 tracking-tight">Common Questions</h2>
          </div>
          <div className="max-w-4xl border-t border-slate-200">
            {faqs.map((faq, index) => (
              <FAQItem key={index} question={faq.question} answer={faq.answer} />
            ))}
          </div>
        </div>

        {/* Comparison Table */}
        <div className="mt-32">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold mb-4 tracking-tight">Answering Service vs. AI Agent</h2>
            <p className="text-slate-600">Why paying a human answering service is a relic of the past.</p>
          </div>
          <div className="overflow-x-auto bg-white rounded-2xl border border-slate-200 shadow-sm">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b-2 border-slate-200 bg-slate-50/50">
                  <th className="py-5 px-6 text-sm font-bold uppercase tracking-widest text-slate-400">Feature</th>
                  <th className="py-5 px-6 text-sm font-bold uppercase tracking-widest text-slate-900">Human Answering Service</th>
                  <th className="py-5 px-6 text-sm font-bold uppercase tracking-widest text-blue-600">Anthros Digital AI</th>
                </tr>
              </thead>
              <tbody className="text-slate-600">
                <tr className="border-b border-slate-100">
                  <td className="py-6 px-6 font-bold text-slate-900">Monthly Cost</td>
                  <td className="py-6 px-6">$300 - $1,000+</td>
                  <td className="py-6 px-6 font-bold text-blue-600">Fixed, lower overhead</td>
                </tr>
                <tr className="border-b border-slate-100">
                  <td className="py-6 px-6 font-bold text-slate-900">Product Knowledge</td>
                  <td className="py-6 px-6">Follows basic scripts</td>
                  <td className="py-6 px-6 font-bold text-blue-600">Deep expertise in YOUR trade</td>
                </tr>
                <tr className="border-b border-slate-100">
                  <td className="py-6 px-6 font-bold text-slate-900">Wait Time</td>
                  <td className="py-6 px-6">Depends on operator count</td>
                  <td className="py-6 px-6 font-bold text-blue-600">Instant (Concurrent traffic)</td>
                </tr>
                <tr>
                  <td className="py-6 px-6 font-bold text-slate-900">Lead Quality</td>
                  <td className="py-6 px-6">Transcription mistakes</td>
                  <td className="py-6 px-6 font-bold text-blue-600">Perfect data, instantly synced</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* Closing CTA */}
        <div className="mt-32 p-12 bg-slate-900 rounded-3xl text-center text-white relative overflow-hidden shadow-2xl">
          <div className="absolute top-0 left-0 w-full h-full bg-blue-600/10 pointer-events-none"></div>
          <h2 className="text-4xl font-bold mb-6 tracking-tight">Stop Working For Your Website.</h2>
          <p className="text-xl text-slate-400 mb-10 max-w-2xl mx-auto">
            Make your website work for you. Let's build an AI Agent that knows Rockland County as well as you do.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button 
              onClick={onGetDemo}
              className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 rounded-md font-bold text-lg transition-all shadow-lg shadow-blue-600/20 active:scale-95"
            >
              GET AN AI DEMO
            </button>
            <button 
              onClick={onBack}
              className="bg-transparent border border-slate-700 hover:bg-slate-800 text-white px-8 py-4 rounded-md font-bold text-lg transition-all active:scale-95"
            >
              BACK TO HOME
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WhyAIPage;
