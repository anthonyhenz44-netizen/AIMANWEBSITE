
import React from 'react';
import { ArrowLeft, ShieldCheck, FileText, Lock } from 'lucide-react';

interface LegalPageProps {
  type: 'privacy' | 'terms';
  onBack: () => void;
}

const LegalPage: React.FC<LegalPageProps> = ({ type, onBack }) => {
  const isPrivacy = type === 'privacy';

  return (
    <div className="bg-white min-h-screen py-20">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <button 
          onClick={onBack}
          className="flex items-center gap-2 text-blue-600 font-bold text-sm uppercase tracking-widest mb-12 hover:gap-3 transition-all"
        >
          <ArrowLeft size={18} /> Back to Home
        </button>

        <div className="flex items-center gap-4 mb-8">
          <div className="p-3 bg-blue-100 text-blue-600 rounded-xl">
            {isPrivacy ? <Lock size={32} /> : <FileText size={32} />}
          </div>
          <h1 className="text-4xl font-bold text-slate-900 tracking-tight">
            {isPrivacy ? 'Privacy Policy' : 'Terms of Service'}
          </h1>
        </div>

        <div className="prose prose-slate max-w-none text-slate-600 leading-relaxed">
          <p className="text-sm font-bold uppercase text-slate-400 mb-8">Last Updated: 1/30/2026</p>

          {isPrivacy ? (
            <div className="space-y-8">
              <section>
                <h2 className="text-2xl font-bold text-slate-900 mb-4 tracking-tight">1. Information We Collect</h2>
                <p>
                  At Anthros Digital AI Web Solutions, we collect personal information that you provide to us directly. This includes:
                </p>
                <ul className="list-disc pl-6 mt-4 space-y-2">
                  <li>Contact details such as name, email address, and phone number when you request a demo or use our chatbot.</li>
                  <li>Business details relevant to the services we provide, such as your trade, service area, and business name.</li>
                  <li>Communication history between you and our AI intake agents.</li>
                </ul>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-slate-900 mb-4 tracking-tight">2. How We Use Your Information</h2>
                <p>We use the information we collect to:</p>
                <ul className="list-disc pl-6 mt-4 space-y-2">
                  <li>Provide and improve our AI-powered web solutions.</li>
                  <li>Communicate with you regarding demo requests, service updates, and marketing (with your consent).</li>
                  <li>Facilitate lead generation for your own business through our AI agents.</li>
                  <li>Monitor and analyze usage trends to improve user experience.</li>
                </ul>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-slate-900 mb-4 tracking-tight">3. Data Sharing and Third Parties</h2>
                <p>
                  We do not sell your personal data. We may share information with trusted third-party service providers who assist us in operating our business, such as:
                </p>
                <ul className="list-disc pl-6 mt-4 space-y-2">
                  <li>Google Cloud Platform (for Gemini AI and hosting).</li>
                  <li>SMS and Email service providers for automation.</li>
                  <li>Legal authorities when required by law.</li>
                </ul>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-slate-900 mb-4 tracking-tight">4. Security</h2>
                <p>
                  We implement industry-standard security measures to protect your data. However, no method of transmission over the internet is 100% secure. We strive to use commercially acceptable means to protect your personal information.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-slate-900 mb-4 tracking-tight">5. Contact Us</h2>
                <p>If you have any questions about this Privacy Policy, please contact us at:</p>
                <div className="mt-4 p-6 bg-slate-50 rounded-xl border border-slate-100">
                  <p className="font-bold text-slate-900">Anthros Digital AI Web Solutions</p>
                  <p>Email: anthrosdigitalweb@gmail.com</p>
                  <p>Phone: (929) 610-1826</p>
                  <p>Rockland County, NY</p>
                </div>
              </section>
            </div>
          ) : (
            <div className="space-y-8">
              <section>
                <h2 className="text-2xl font-bold text-slate-900 mb-4 tracking-tight">1. Acceptance of Terms</h2>
                <p>
                  By accessing and using the services provided by Anthros Digital AI Web Solutions, you agree to comply with and be bound by these Terms of Service. If you do not agree, please refrain from using our site or services.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-slate-900 mb-4 tracking-tight">2. Description of Service</h2>
                <p>
                  Anthros Digital provides custom AI-powered web design and lead generation automation. Our "Intake Agents" are powered by third-party large language models (LLMs). While we strive for accuracy, AI responses are generated based on provided data and may occasionally contain errors.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-slate-900 mb-4 tracking-tight">3. User Obligations</h2>
                <p>
                  Users agree to provide accurate information when requesting demos or service. Misuse of our AI agents for illegal, harassing, or deceptive purposes is strictly prohibited.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-slate-900 mb-4 tracking-tight">4. Intellectual Property</h2>
                <p>
                  All content on this website, including but not limited to the Anthros Digital name, logo, and AI implementation logic, is the property of Anthros Digital and protected by intellectual property laws.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-slate-900 mb-4 tracking-tight">5. Limitation of Liability</h2>
                <p>
                  Anthros Digital shall not be liable for any indirect, incidental, or consequential damages resulting from the use or inability to use our services, including but not limited to lost profits or business interruptions caused by AI downtime or technical issues.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-slate-900 mb-4 tracking-tight">6. Governing Law</h2>
                <p>
                  These terms are governed by the laws of the State of New York. Any disputes shall be resolved in the courts of Rockland County, NY.
                </p>
              </section>
            </div>
          )}
        </div>

        <div className="mt-20 pt-12 border-t border-slate-100 text-center">
          <button 
            onClick={onBack}
            className="bg-blue-600 text-white px-8 py-4 rounded-md font-bold hover:bg-blue-700 transition-all shadow-lg shadow-blue-600/20 active:scale-95"
          >
            Back to Home
          </button>
        </div>
      </div>
    </div>
  );
};

export default LegalPage;
